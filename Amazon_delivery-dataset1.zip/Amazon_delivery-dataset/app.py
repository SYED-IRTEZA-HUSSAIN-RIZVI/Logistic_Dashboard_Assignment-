# app.py
from flask import Flask, render_template, request
import joblib
import pandas as pd

app = Flask(__name__)
model = joblib.load('delivery_time_predictor.pkl')
data = pd.read_csv('amazon_delivery.csv')


@app.route('/')
def dashboard():
    avg_time = round(data['Delivery Time (min)'].mean(), 2)
    busiest_city = data['City'].value_counts().idxmax()
    late_deliveries = data[data['Late'] == 1].shape[0]
    return render_template('dashboard.html', avg_time=avg_time, busiest_city=busiest_city, late_deliveries=late_deliveries)

@app.route('/predict', methods=['POST'])
def predict():
    input_data = [float(request.form[key]) for key in request.form]
    prediction = model.predict([input_data])[0]
    return render_template('predict.html', prediction=round(prediction, 2))

if __name__ == '__main__':
    app.run(debug=True)

