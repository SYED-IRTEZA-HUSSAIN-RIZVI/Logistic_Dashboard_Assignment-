import pandas as pd
from sklearn.linear_model import LinearRegression
import joblib

data = pd.read_csv('amazon_delivery.csv')
x = data[['Distance (km)', 'Package Weight (kg)', 'Traffic Density']]
y = data['Delivery Time (min)']

model = LinearRegression()
model.fit(x, y)

joblib.dump(model, 'delivery_time_predictor.pkl')

